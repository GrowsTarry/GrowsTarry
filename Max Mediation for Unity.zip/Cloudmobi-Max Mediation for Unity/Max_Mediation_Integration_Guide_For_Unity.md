# Max Mediation Integration Guide

This guide instructs you step-by-step on how to set GrowsTarry live as an Ad Network on the Max Mediation platform.

Currently we support Rewarded Video, Banner and Interstitial for mediation.


### Step 1: Integrate GrowsTarry SDK and Adapter

* Import UnityPlugin

* Update the AndroidManifest.xml

 ```
    <!--Necessary Permissions-->
	<uses-permission android:name="android.permission.INTERNET"/>
	<uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />

	<!-- Necessary -->
    <activity android:name="com.growstarry.kern.view.InnerWebViewActivity" />

    <provider
        android:authorities="${applicationId}.xxprovider"
        android:name="com.growstarry.kern.core.GrowsTarryProvider"
        android:exported="false"/>	


    <!-- for growstarry rewardvideo -->
    <activity
        android:name="com.growstarry.video.view.RewardedVideoActivity"
        android:configChanges="keyboard|keyboardHidden|orientation|screenLayout|uiMode|screenSize|smallestScreenSize" />

    <!-- for growstarry interstitial ads -->
    <activity android:name="com.growstarry.kern.view.InterstitialActivity" />
 ```

### Step 2: Create Network

![image-20220915181728356](https://github.com/GrowsTarry/GrowsTarry/blob/cdc75a023092f7207960b887a57780e2e63676dc/img/image-20220915181728356.png?raw=true)

* **Configure Adapter Address**

![image-20220915181848203](https://github.com/GrowsTarry/GrowsTarry/blob/cdc75a023092f7207960b887a57780e2e63676dc/img/image-20220915181848203.png?raw=true)

### Step 3: Create Ad Unit

![image-20220915182406288](https://github.com/GrowsTarry/GrowsTarry/blob/cdc75a023092f7207960b887a57780e2e63676dc/img/image-20220915182406288.png?raw=true)

<img src="https://github.com/GrowsTarry/GrowsTarry/blob/cdc75a023092f7207960b887a57780e2e63676dc/img/image-20220915182437154.png?raw=true" alt="image-20220915182437154"  />

![image-20220915182536134](https://github.com/GrowsTarry/GrowsTarry/blob/cdc75a023092f7207960b887a57780e2e63676dc/img/image-20220915182536134.png?raw=true)



### Step 5. Add ProGuard Rules

```
    #for sdk
    -keep public class com.growstarry.**{*;}
    -dontwarn com.growstarry.**

    #for gaid
    -keep class **.AdvertisingIdClient$** { *; }

    #for js and webview interface
    -keepclassmembers class * {
        @android.webkit.JavascriptInterface <methods>;
    }

```
**Done!** You are now all set to deliver GrowsTarry Ads within your application!


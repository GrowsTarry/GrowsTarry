package com.growstarry.mediation.topon;

import android.graphics.Bitmap;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;

import com.anythink.nativead.api.ATNativePrepareInfo;
import com.anythink.nativead.unitgroup.api.CustomNativeAd;
import com.growstarry.kern.core.GTAdvanceNative;

import java.util.List;

public class GrowsTarryNativeAd extends CustomNativeAd {

    private static String TAG = "OM-AG-Native:";
    private GTAdvanceNative mAgNative;


    public GrowsTarryNativeAd(GTAdvanceNative agNative) {
        mAgNative = agNative;
        setAdData();
    }

    public void setAdData() {
        setTitle(mAgNative.getTitle());
        setDescriptionText(mAgNative.getDesc());
        setIconImageUrl(mAgNative.getIconUrl());
        setMainImageUrl(mAgNative.getImageUrl());
        setCallToActionText(mAgNative.getButtonStr());
        try {
            setStarRating(Double.parseDouble(mAgNative.getRate()));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    @Override
    public void prepare(View view, ATNativePrepareInfo nativePrepareInfo) {
        List<View> clickViewList = nativePrepareInfo.getClickViewList();
        if (mAgNative != null && clickViewList != null && clickViewList.size() > 1) {
            ViewParent parentView = clickViewList.get(0).getParent();
            if (parentView instanceof ViewGroup) {
                mAgNative.registeADClickArea((ViewGroup) parentView);
            }

        }
    }


    public void onClick() {
        notifyAdClicked();
        Log.d(TAG, "onClick");
    }

    @Override
    public Bitmap getAdLogo() {
        return null;
    }

    @Override
    public void clear(final View view) {

    }

    @Override
    public View getAdMediaView(Object... object) {
//        if (mAgNative != null) {
//            return mAgNative;
//        }
        return null;
    }

    @Override
    public boolean isNativeExpress() {
        return false;
    }

    @Override
    public void destroy() {
        Log.i(TAG, "destroy()");
        if (mAgNative != null) {
            mAgNative = null;
        }
    }


}

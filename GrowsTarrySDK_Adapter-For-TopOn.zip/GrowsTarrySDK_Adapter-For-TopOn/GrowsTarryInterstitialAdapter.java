package com.growstarry.mediation.topon;

import android.app.Activity;
import android.content.Context;
import android.text.TextUtils;
import android.util.Log;

import com.anythink.interstitial.unitgroup.api.CustomInterstitialAdapter;
import com.growstarry.kern.callback.EmptyAdEventListener;
import com.growstarry.kern.config.Const;
import com.growstarry.kern.core.GTNative;
import com.growstarry.kern.core.GrowsTarrySDK;

import java.util.Map;

public class GrowsTarryInterstitialAdapter extends CustomInterstitialAdapter {

    String slotId = null;
    private GTNative agnv = null;
    private boolean isDestroyed;
    private String TAG = "GrowsTarryInterstitialAdapter:";
    @Override
    public boolean isAdReady() {
        if (isDestroyed) {
            return false;
        }

        return GrowsTarrySDK.isInterstitialAvailable(agnv);
    }

    @Override
    public void show(Activity activity) {
        if (isDestroyed) {
            return;
        }

        if (GrowsTarrySDK.isInterstitialAvailable(agnv)) {
            GrowsTarrySDK.showInterstitialAd(agnv);
            Log.d(TAG, "InterstitialAvailable show.");
            if (mImpressListener != null) {
                mImpressListener.onInterstitialAdShow();
            }
        }
    }

    @Override
    public String getNetworkName() {
        return Const.getVersionNumber();
    }

    @Override
    public void loadCustomNetworkAd(final Context context, Map<String, Object> serverExtra, final Map<String, Object> localExtra) {
        slotId = (String) serverExtra.get("slot_id");
        if ( TextUtils.isEmpty(slotId)) {
            if (mLoadListener != null) {
                mLoadListener.onAdLoadError(TAG, "slot_id is empty!");
            }
            return;
        }
        GrowsTarrySDK.initialize(context, slotId);
        GrowsTarrySDK.preloadInterstitialAd(context, slotId, new InterstitialAdListener(){
            @Override
            public void onShowSucceed(GTNative result) {
                super.onShowSucceed(result);
            }
            @Override
            public void onReceiveAdSucceed(GTNative agNative) {
                super.onReceiveAdSucceed(agNative);
                if (isDestroyed) {
                    return;
                }

                Log.d(TAG, "onAdDataLoaded.");
                if (agNative != null && agNative.isLoaded()) {
                    agnv = agNative;
                    if (mLoadListener != null) {
                        mLoadListener.onAdCacheLoaded();
//                        mLoadListener.onAdDataLoaded();
                    }
                }else {
                    Log.d(TAG, "Back parameter error.");
                    if (mLoadListener != null) {
                        mLoadListener.onAdLoadError("","Back parameter error.");
                    }
                }
            }

            @Override
            public void onLandPageShown(GTNative var1) {
                super.onLandPageShown(var1);
                Log.d(TAG, "onLandPageShown");
            }

            @Override
            public void onAdClicked(GTNative var1) {
                super.onAdClicked(var1);
                if (isDestroyed) {
                    return;
                }
                if (mImpressListener != null) {
                    Log.d(TAG, "onInterstitialAdClicked");
                    mImpressListener.onInterstitialAdClicked();
                }
            }

            @Override
            public void onReceiveAdFailed(GTNative var1) {
                super.onReceiveAdFailed(var1);
                Log.d(TAG, "onReceiveAdFailed");
                if (isDestroyed) {
                    return;
                }
                if (mLoadListener != null) {
                    String err = "onReceiveAdFailed";
                    if (null != var1) {
                        err = var1.getErrorsMsg();
                    }
                    mLoadListener.onAdLoadError("",err);

                }
            }


            @Override
            public void onAdClosed(GTNative var1) {
                super.onAdClosed(var1);
                if (isDestroyed) {
                    return;
                }
                Log.d(TAG, "onInterstitialAdClose");
                if (mImpressListener != null) {
                    mImpressListener.onInterstitialAdClose();
                }
            }
        });

    }

    @Override
    public void destory() {
        isDestroyed = true;
        if (null != agnv) {
            agnv= null;
        }
    }

    @Override
    public String getNetworkPlacementId() {
        return slotId;
    }

    @Override
    public String getNetworkSDKVersion() {
        return Const.getVersionNumber();
    }

    private static int px2dip(Context context, float pxValue) {
        final float scale = context.getResources().getDisplayMetrics().density;
        return (int) (pxValue / (scale <= 0 ? 1 : scale) + 0.5f);
    }

    static class InterstitialAdListener extends EmptyAdEventListener {

        @Override
        public void onReceiveAdSucceed(GTNative agNative) {

        }

        @Override
        public void onLandPageShown(GTNative var1) {

        }

        @Override
        public void onAdClicked(GTNative var1) {

        }

        @Override
        public void onReceiveAdFailed(GTNative var1) {

        }


        @Override
        public void onAdClosed(GTNative var1) {

        }
    }
}

package com.mopub.mediation.gt;
import android.app.Activity;
import android.content.Context;
import android.text.TextUtils;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.growstarry.kern.callback.VideoAdLoadListener;
import com.growstarry.kern.core.GTError;
import com.growstarry.kern.core.GTVideo;
import com.growstarry.video.core.GrowsTarryVideo;
import com.growstarry.video.core.RewardedVideoAdListener;
import com.mopub.common.LifecycleListener;
import com.mopub.common.MoPubReward;
import com.mopub.common.Preconditions;
import com.mopub.common.logging.MoPubLog;
import com.mopub.mobileads.AdData;
import com.mopub.mobileads.BaseAd;
import com.mopub.mobileads.MoPubErrorCode;

import java.util.Map;

import static com.mopub.common.logging.MoPubLog.AdapterLogEvent.CLICKED;
import static com.mopub.common.logging.MoPubLog.AdapterLogEvent.CUSTOM;
import static com.mopub.common.logging.MoPubLog.AdapterLogEvent.DID_DISAPPEAR;
import static com.mopub.common.logging.MoPubLog.AdapterLogEvent.LOAD_FAILED;
import static com.mopub.common.logging.MoPubLog.AdapterLogEvent.LOAD_SUCCESS;
import static com.mopub.common.logging.MoPubLog.AdapterLogEvent.SHOW_SUCCESS;

public class GTAdRewardedVideo extends BaseAd {
    private static final String ADAPTER_NAME = GTAdRewardedVideo.class.getSimpleName();
    private String mPlacementId;
    private GTAdapterConfiguration mGTAdapterConfiguration;
    private GTVideo mVideo;

    public GTAdRewardedVideo() {
        mGTAdapterConfiguration = new GTAdapterConfiguration();
    }

    private boolean hasVideoAvailable() {
        return GrowsTarryVideo.isRewardedVideoAvailable(mVideo);
    }

    @Nullable
    @Override
    protected LifecycleListener getLifecycleListener() {
        return null;
    }

    @Override
    protected boolean checkAndInitializeSdk(@NonNull Activity activity, @NonNull final AdData adData) {
        return false;
    }

    @Override
    protected void load(@NonNull final Context context, @NonNull final AdData adData) {
        Preconditions.checkNotNull(context);
        Preconditions.checkNotNull(adData);

        if (!(context instanceof Activity)) {
            MoPubLog.log(getAdNetworkId(), CUSTOM, ADAPTER_NAME, "Context passed to load " +
                    "was not an Activity. Failing the request.");
            if (mLoadListener != null) {
                mLoadListener.onAdLoadFailed(MoPubErrorCode.ADAPTER_CONFIGURATION_ERROR);
            }
            return;
        }

        /** obtain adunit from server by mopub */
        final Map<String, String> extras = adData.getExtras();

        if (extras == null || extras.isEmpty()) {
            if (mLoadListener != null) {
                mLoadListener.onAdLoadFailed(MoPubErrorCode.ADAPTER_CONFIGURATION_ERROR);
            }
        }

        mPlacementId = extras.get(mGTAdapterConfiguration.AD_PLACEMENT_ID_EXTRA_KEY);

        if (null == mPlacementId || TextUtils.isEmpty(mPlacementId)) {
            MoPubLog.log(getAdNetworkId(), CUSTOM, ADAPTER_NAME,
                    "Invalid growstarry placement ID. Failing ad request. " +
                            "Ensure the ad placement ID is valid on the MoPub dashboard.");
            if (mLoadListener != null) {
                mLoadListener.onAdLoadFailed(MoPubErrorCode.ADAPTER_CONFIGURATION_ERROR);
            }
            return;
        }
        final String appId = extras.get(GTAdapterConfiguration.APP_ID_EXTRA_KEY);
        GTAdapterConfiguration.GTSdkInit(context, appId);
        GrowsTarryVideo.preloadRewardedVideo(context, mPlacementId,
            new VideoAdLoadListener() {
                @Override
                public void onVideoAdLoadSucceed(GTVideo video) {
                    if (null != video) {
                        mVideo = video;
                        MoPubLog.log(getAdNetworkId(), LOAD_SUCCESS, ADAPTER_NAME);
                        if (mLoadListener != null) {
                            mLoadListener.onAdLoaded();
                        }
                    }else {
                        MoPubLog.log(getAdNetworkId(), LOAD_FAILED, ADAPTER_NAME, "Rewarded Video is null.");
                        if (mLoadListener != null) {
                            mLoadListener.onAdLoadFailed(MoPubErrorCode.NETWORK_NO_FILL);
                        }
                    }
                }

                @Override
                public void onVideoAdLoadFailed(GTError error) {
                    MoPubLog.log(getAdNetworkId(), LOAD_FAILED, ADAPTER_NAME,
                            "Loading Rewarded Video creative encountered an error: "
                                    + error.getMsg());
                    if (mLoadListener != null) {
                        mLoadListener.onAdLoadFailed(MoPubErrorCode.VIDEO_DOWNLOAD_ERROR);
                    }
                }
            });
    }

    @Override
    protected void show() {
            if (hasVideoAvailable()) {
            GrowsTarryVideo.showRewardedVideo(mVideo, new RewardedVideoAdListener() {

                @Override
                public void videoStart() {
                    MoPubLog.log(getAdNetworkId(), SHOW_SUCCESS, ADAPTER_NAME);
                    if (mInteractionListener != null) {
                        mInteractionListener.onAdShown();
                        mInteractionListener.onAdImpression();
                    }
                }

                @Override
                public void videoFinish() {
                    MoPubLog.log(getAdNetworkId(), CUSTOM, ADAPTER_NAME, "onVideoComplete.");
                }

                @Override
                public void videoError(Exception e) {
                    MoPubLog.log(getAdNetworkId(), CUSTOM, ADAPTER_NAME, "onVideoError.");
                    if (mInteractionListener != null) {
                        mInteractionListener.onAdFailed(MoPubErrorCode.AD_SHOW_ERROR);
                    }
                }

                @Override
                public void videoClosed() {
                    MoPubLog.log(getAdNetworkId(), DID_DISAPPEAR, ADAPTER_NAME);
                    MoPubLog.log(getAdNetworkId(), CUSTOM, ADAPTER_NAME, "onAdClose.");
                    if (mInteractionListener != null) {
                        mInteractionListener.onAdDismissed();
                    }
                }

                @Override
                public void videoClicked() {
                    MoPubLog.log(getAdNetworkId(), CLICKED, ADAPTER_NAME);
                    if (mInteractionListener != null) {
                        mInteractionListener.onAdClicked();
                    }
                }

                @Override
                public void videoRewarded(String rewardName, String rewardAmount) {
                    int count= 0;
                    if (null != rewardAmount && !rewardAmount.isEmpty()) {
                        count = Integer.parseInt(rewardAmount);
                    }
                    if (mInteractionListener != null) {
                        mInteractionListener.onAdComplete(MoPubReward.success(rewardName,count));
                    }
                }
            });
        } else {
            MoPubLog.d("Attempted to show rewarded video before it was available.");
        }
    }

    @NonNull
    @Override
    protected String getAdNetworkId() {
        return mPlacementId;
    }

    @Override
    protected void onInvalidate() {
          mVideo = null;
    }

}

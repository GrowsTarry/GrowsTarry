package com.mopub.mediation.gt;

import android.app.Activity;
import android.content.Context;
import android.text.TextUtils;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.growstarry.kern.callback.AdEventListener;
import com.growstarry.kern.core.GTNative;
import com.growstarry.kern.core.GrowsTarrySDK;
import com.growstarry.kern.vo.AdsVO;
import com.mopub.common.LifecycleListener;
import com.mopub.common.Preconditions;
import com.mopub.common.logging.MoPubLog;
import com.mopub.mobileads.AdData;
import com.mopub.mobileads.BaseAd;
import com.mopub.mobileads.MoPubErrorCode;

import java.util.Map;

import static com.mopub.common.logging.MoPubLog.AdLogEvent.DID_DISAPPEAR;
import static com.mopub.common.logging.MoPubLog.AdapterLogEvent.CLICKED;
import static com.mopub.common.logging.MoPubLog.AdapterLogEvent.CUSTOM;
import static com.mopub.common.logging.MoPubLog.AdapterLogEvent.LOAD_ATTEMPTED;
import static com.mopub.common.logging.MoPubLog.AdapterLogEvent.LOAD_FAILED;
import static com.mopub.common.logging.MoPubLog.AdapterLogEvent.LOAD_SUCCESS;
import static com.mopub.common.logging.MoPubLog.AdapterLogEvent.SHOW_FAILED;
import static com.mopub.common.logging.MoPubLog.AdapterLogEvent.SHOW_SUCCESS;

public class GTAdInterstitial extends BaseAd {
    private static final String ADAPTER_NAME = GTAdInterstitial.class.getSimpleName();

    private String mPlacementId;
    private Context mContext;
    private GTAdapterConfiguration mGTAdapterConfiguration;
    private GTNative zcNative;

    public GTAdInterstitial() {
        mGTAdapterConfiguration = new GTAdapterConfiguration();
    }

    @Override
    protected void load(@NonNull final Context context, @NonNull final AdData adData) {
        Preconditions.checkNotNull(context);
        Preconditions.checkNotNull(adData);

        mContext = context;
        setAutomaticImpressionAndClickTracking(false);
        final Map<String, String> extras = adData.getExtras();

        String adm = null;

        if (extras == null || extras.isEmpty()) {
            if (mLoadListener != null) {
                mLoadListener.onAdLoadFailed(MoPubErrorCode.ADAPTER_CONFIGURATION_ERROR);
            }
        }

        mPlacementId = extras.get(GTAdapterConfiguration.AD_PLACEMENT_ID_EXTRA_KEY);

        if (TextUtils.isEmpty(mPlacementId)) {
            MoPubLog.log(getAdNetworkId(), CUSTOM, ADAPTER_NAME,
                    "Invalid growstarry placement ID. Failing ad request. " +
                            "Ensure the ad placement ID is valid on the MoPub dashboard.");

            if (mLoadListener != null) {
                mLoadListener.onAdLoadFailed(MoPubErrorCode.ADAPTER_CONFIGURATION_ERROR);
            }

            return;
        }


        /** Init growstarry SDK if fail to initialize in the adapterConfiguration */
        final String appId = extras.get(GTAdapterConfiguration.APP_ID_EXTRA_KEY);
        GTAdapterConfiguration.GTSdkInit(context, appId);
        mGTAdapterConfiguration.setCachedInitializationParameters(context, extras);
        MoPubLog.log(getAdNetworkId(), LOAD_ATTEMPTED, ADAPTER_NAME);

        GrowsTarrySDK.preloadInterstitialAd(context, mPlacementId, new AdEventListener() {

            @Override
            public void onReceiveAdSucceed(GTNative result) {
                if (null != result) {
                    zcNative = result;
                    MoPubLog.log(getAdNetworkId(), LOAD_SUCCESS, ADAPTER_NAME);
                    if (null != mLoadListener) {
                        mLoadListener.onAdLoaded();
                    }
                }else {
                    MoPubLog.log(getAdNetworkId(), LOAD_FAILED, ADAPTER_NAME);
                    if (null != mLoadListener) {
                        mLoadListener.onAdLoadFailed(MoPubErrorCode.FULLSCREEN_LOAD_ERROR);
                    }
                }
            }

            @Override
            public void onReceiveAdVoSucceed(AdsVO result) {

            }

            @Override
            public void onReceiveAdFailed(GTNative result) {
                MoPubLog.log(getAdNetworkId(), LOAD_FAILED, ADAPTER_NAME);
                if (null != mLoadListener) {
                    mLoadListener.onAdLoadFailed(MoPubErrorCode.FULLSCREEN_LOAD_ERROR);
                }
            }

            @Override
            public void onLandPageShown(GTNative result) {

            }


            @Override
            public void onAdClicked(GTNative result) {
                MoPubLog.log(getAdNetworkId(), CLICKED, ADAPTER_NAME);
                if (mInteractionListener != null) {
                    mInteractionListener.onAdClicked();
                }
            }


            @Override
            public void onAdClosed(GTNative result) {
                MoPubLog.log(getAdNetworkId(), DID_DISAPPEAR, ADAPTER_NAME);
                if (mInteractionListener != null) {
                    mInteractionListener.onAdDismissed();
                }
            }

        });

    }

    @Override
    protected void show() {
        if (GrowsTarrySDK.isInterstitialAvailable(zcNative)) {
            GrowsTarrySDK.showInterstitialAd(zcNative);
            MoPubLog.log(getAdNetworkId(), SHOW_SUCCESS, ADAPTER_NAME);
            if (mInteractionListener != null) {
                mInteractionListener.onAdShown();
                mInteractionListener.onAdImpression();
            }
        } else {
            MoPubLog.log(getAdNetworkId(), SHOW_FAILED, ADAPTER_NAME);
            if (mInteractionListener != null) {
                mInteractionListener.onAdFailed(MoPubErrorCode.NETWORK_INVALID_STATE);
            }
        }
    }

    @NonNull
    public String getAdNetworkId() {
        return mPlacementId == null ? "" : mPlacementId;
    }

    @Override
    protected boolean checkAndInitializeSdk(@NonNull Activity launcherActivity, @NonNull AdData adData) throws Exception {
        return false;
    }

    @Override
    protected void onInvalidate() {

    }

    @Nullable
    @Override
    protected LifecycleListener getLifecycleListener() {
        return null;
    }
}

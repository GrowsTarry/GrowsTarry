package com.mopub.mediation.gt;

import android.content.Context;
import android.text.TextUtils;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.growstarry.kern.config.Const;
import com.growstarry.kern.utils.HttpRequester;
import com.growstarry.kern.core.GrowsTarrySDK;
import com.mopub.common.BaseAdapterConfiguration;
import com.mopub.common.MoPub;
import com.mopub.common.OnNetworkInitializationFinishedListener;
import com.mopub.common.Preconditions;
import com.mopub.common.logging.MoPubLog;
import com.mopub.mobileads.MoPubErrorCode;

import java.util.Map;

import static com.mopub.common.logging.MoPubLog.AdapterLogEvent.CUSTOM;
import static com.mopub.common.logging.MoPubLog.AdapterLogEvent.CUSTOM_WITH_THROWABLE;

public class GTAdapterConfiguration extends BaseAdapterConfiguration {

    private static final String ADAPTER_VERSION = "1.0";
    private static final String ADAPTER_NAME = GTAdapterConfiguration.class.getSimpleName();
    private static final String MOPUB_NETWORK_NAME = "growstarry";
    public static final String AD_PLACEMENT_ID_EXTRA_KEY = "ad_placement_id";
    public static final String APP_ID_EXTRA_KEY = "app_id";

    @NonNull
    @Override
    public String getAdapterVersion() {
        return ADAPTER_VERSION;
    }

    @Nullable
    @Override
    public String getBiddingToken(@NonNull Context context) {
        return null;
    }

    @NonNull
    @Override
    public String getMoPubNetworkName() {
        return MOPUB_NETWORK_NAME;
    }

    @NonNull
    @Override
    public String getNetworkSdkVersion() {
        return  Const.getVersionNumber();
    }

    @Override
    public void initializeNetwork(@NonNull Context context, @Nullable Map<String, String> configuration, @NonNull OnNetworkInitializationFinishedListener listener) {
        Preconditions.checkNotNull(context);
        Preconditions.checkNotNull(listener);

        boolean networkInitializationSucceeded = false;
        synchronized (GTAdapterConfiguration.class) {
            try {
                if (configuration != null && !configuration.isEmpty()) {
                    final String appId = configuration.get(APP_ID_EXTRA_KEY);

                    GTSdkInit(context, appId);
                    networkInitializationSucceeded = true;
                } else {
                    MoPubLog.log(CUSTOM, ADAPTER_NAME,
                            "growstarry SDK is not initialized, please check whether app ID is empty or null in sdkConfiguration.");
                }
            } catch (Exception e) {
                MoPubLog.log(CUSTOM_WITH_THROWABLE, "Initializing growstarry has encountered " +
                        "an exception.", e);
            }
        }

        if (networkInitializationSucceeded) {
            listener.onNetworkInitializationFinished(GTAdapterConfiguration.class,
                    MoPubErrorCode.ADAPTER_INITIALIZATION_SUCCESS);
        } else {
            listener.onNetworkInitializationFinished(GTAdapterConfiguration.class,
                    MoPubErrorCode.ADAPTER_CONFIGURATION_ERROR);
        }
    }

    public static void GTSdkInit(Context context, String appId) {
        if (TextUtils.isEmpty(appId) || context == null) {
            MoPubLog.log(CUSTOM, ADAPTER_NAME,
                    "Invalid  app ID. Ensure the app id is valid on the MoPub dashboard.");
            return;
        }
        GrowsTarrySDK.initialize(context,appId);
        GrowsTarrySDK.uploadConsent(context, MoPub.canCollectPersonalInformation(), "GDPR", new HttpRequester.Listener() {
            @Override
            public void onGetDataSucceed(byte[] data) {
            }


            @Override
            public void onGetDataFailed(String error) {
            }
        });
    }


}

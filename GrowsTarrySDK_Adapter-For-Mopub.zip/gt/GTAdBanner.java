package com.mopub.mediation.gt;

import android.app.Activity;
import android.content.Context;
import android.text.TextUtils;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.growstarry.kern.callback.AdEventListener;
import com.growstarry.kern.core.GTNative;
import com.growstarry.kern.core.GrowsTarrySDK;
import com.growstarry.kern.enums.AdSize;
import com.growstarry.kern.vo.AdsVO;
import com.mopub.common.LifecycleListener;
import com.mopub.common.Preconditions;
import com.mopub.common.logging.MoPubLog;
import com.mopub.mobileads.AdData;
import com.mopub.mobileads.BaseAd;
import com.mopub.mobileads.MoPubErrorCode;
import java.util.Map;

import static com.mopub.common.logging.MoPubLog.AdapterLogEvent.CLICKED;
import static com.mopub.common.logging.MoPubLog.AdapterLogEvent.CUSTOM;
import static com.mopub.common.logging.MoPubLog.AdapterLogEvent.LOAD_FAILED;
import static com.mopub.common.logging.MoPubLog.AdapterLogEvent.LOAD_SUCCESS;
import static com.mopub.common.logging.MoPubLog.AdapterLogEvent.SHOW_SUCCESS;

public class GTAdBanner extends BaseAd {
    private static final String ADAPTER_NAME = GTAdBanner.class.getSimpleName();

    private static String mPlacementId;
    private GTAdapterConfiguration mGTAdapterConfiguration;
    private int mBannerWidth;
    private int mBannerHeight;
    private View mBannerView;

    public GTAdBanner() {
        mGTAdapterConfiguration = new GTAdapterConfiguration();
    }

    @Override
    protected void load(@NonNull final Context context, @NonNull final AdData adData) {
        Preconditions.checkNotNull(context);
        Preconditions.checkNotNull(adData);

        setAutomaticImpressionAndClickTracking(false);

        final Map<String, String> extras = adData.getExtras();
        if (extras == null || extras.isEmpty()) {
            if (mLoadListener != null) {
                mLoadListener.onAdLoadFailed(MoPubErrorCode.ADAPTER_CONFIGURATION_ERROR);
            }
            return;
        }

        mPlacementId = extras.get(GTAdapterConfiguration.AD_PLACEMENT_ID_EXTRA_KEY);

        if (TextUtils.isEmpty(mPlacementId)) {
            MoPubLog.log(getAdNetworkId(), CUSTOM, ADAPTER_NAME,
                    "Invalid growstarry placement ID. Failing ad request. " +
                            "Ensure the ad placement ID is valid on the MoPub dashboard.");

            if (mLoadListener != null) {
                mLoadListener.onAdLoadFailed(MoPubErrorCode.ADAPTER_CONFIGURATION_ERROR);
            }
            return;
        }

        /** Init SDK if fail to initialize in the GTAdapterConfiguration */
        final String appId = extras.get(GTAdapterConfiguration.APP_ID_EXTRA_KEY);
        GTAdapterConfiguration.GTSdkInit(context, appId);
        mGTAdapterConfiguration.setCachedInitializationParameters(context, extras);

        mBannerWidth = adData.getAdWidth();
        mBannerHeight = adData.getAdHeight();
        AdSize ctAdSize = getAdSize(mBannerWidth, mBannerHeight);
        if (null == ctAdSize) {
            if (mLoadListener != null) {
                mLoadListener.onAdLoadFailed(MoPubErrorCode.ADAPTER_CONFIGURATION_ERROR);
            }
            return;
        }

        MoPubLog.log(getAdNetworkId(), CUSTOM, ADAPTER_NAME, "BannerWidth = " + mBannerWidth +
                ", BannerHeight = " + mBannerHeight);
        GrowsTarrySDK.getBannerAd(context, mPlacementId, ctAdSize,
            new AdEventListener() {
                @Override
                public void onReceiveAdSucceed(GTNative zcNative) {
                    if (zcNative != null) {
                        mBannerView = zcNative;
                        if (null != mLoadListener){
                            MoPubLog.log(getAdNetworkId(), LOAD_SUCCESS, ADAPTER_NAME);
                            mLoadListener.onAdLoaded();
                        }
                    } else {
                        if (null != mLoadListener) {
                            mLoadListener.onAdLoadFailed(MoPubErrorCode.NETWORK_INVALID_STATE);
                        }
                    }
                }

                @Override
                public void onReceiveAdVoSucceed(AdsVO result) {
//                    MoPubLog.log(getAdNetworkId(),LOAD_SUCCESS,ADAPTER_NAME);
                }

                @Override
                public void onReceiveAdFailed(GTNative result) {
                    MoPubLog.log(getAdNetworkId(),LOAD_FAILED,ADAPTER_NAME);
                    if (mInteractionListener != null) {
                        mInteractionListener.onAdFailed(MoPubErrorCode.NETWORK_NO_FILL);
                    }
                }

                @Override
                public void onLandPageShown(GTNative result) {
                    MoPubLog.log(getAdNetworkId(), SHOW_SUCCESS, ADAPTER_NAME);
                    if (mInteractionListener != null) {
                        mInteractionListener.onAdShown();
                        mInteractionListener.onAdImpression();
                    }
                }

                @Override
                public void onAdClicked(GTNative result) {
                    MoPubLog.log(getAdNetworkId(), CLICKED, ADAPTER_NAME);
                    if (mInteractionListener != null) {
                        mInteractionListener.onAdClicked();
                    }
                }


                @Override
                public void onAdClosed(GTNative result) {
                    if (mInteractionListener != null) {
                        mInteractionListener.onAdCollapsed();
                    }
                }
        });
    }


    private AdSize getAdSize(int w, int h) {

        if (320 == w && 50 == h){
            return AdSize.AD_SIZE_320X50;
        }

        if (320 == w && 100 == h){
            return AdSize.AD_SIZE_320X100;
        }

        if (300 == w && 250 == h){
            return AdSize.AD_SIZE_300X250;
        }

        return null;
    }

    @NonNull
    public String getAdNetworkId() {
        return mPlacementId == null ? "" : mPlacementId;
    }

    @Override
    protected void onInvalidate() {
        mBannerView = null;
        mGTAdapterConfiguration = null;
    }

    @Override
    protected boolean checkAndInitializeSdk(@NonNull Activity launcherActivity, @NonNull AdData adData) {
        return false;
    }

    @Nullable
    @Override
    protected LifecycleListener getLifecycleListener() {
        return null;
    }

    @Override
    public View getAdView() {
        return mBannerView;
    }

}

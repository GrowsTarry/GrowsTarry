package com.growstarry.mediation.max;

import android.app.Activity;
import android.content.Context;
import android.text.TextUtils;
import android.util.Log;

import com.applovin.impl.mediation.MaxRewardImpl;
import com.applovin.mediation.MaxReward;
import com.applovin.mediation.adapter.MaxAdapterError;
import com.applovin.mediation.adapter.MaxInterstitialAdapter;
import com.applovin.mediation.adapter.MaxRewardedAdapter;
import com.applovin.mediation.adapter.listeners.MaxInterstitialAdapterListener;
import com.applovin.mediation.adapter.listeners.MaxRewardedAdapterListener;
import com.applovin.mediation.adapter.parameters.MaxAdapterInitializationParameters;
import com.applovin.mediation.adapter.parameters.MaxAdapterResponseParameters;
import com.applovin.mediation.adapters.MediationAdapterBase;
import com.applovin.sdk.AppLovinSdk;
import com.growstarry.kern.callback.AdEventListener;
import com.growstarry.kern.callback.VideoAdLoadListener;
import com.growstarry.kern.core.GTError;
import com.growstarry.kern.core.GTNative;
import com.growstarry.kern.core.GTVideo;
import com.growstarry.kern.core.GrowsTarrySDK;
import com.growstarry.kern.vo.AdsVO;
import com.growstarry.video.core.GrowsTarryVideo;
import com.growstarry.video.core.RewardedVideoAdListener;

import java.util.concurrent.atomic.AtomicBoolean;

public class CustomAdapter extends MediationAdapterBase implements MaxInterstitialAdapter, MaxRewardedAdapter {
    private static final AtomicBoolean initialized = new AtomicBoolean();
    private static final String TAG = "CustomAdapter";
    private GTNative interstitial;

    private GTVideo video;

    public CustomAdapter(AppLovinSdk appLovinSdk) {
        super(appLovinSdk);
    }

    @Override
    public void initialize(MaxAdapterInitializationParameters maxAdapterInitializationParameters, Activity activity, OnCompletionListener onCompletionListener) {

        if (initialized.compareAndSet(false, true)) {
            Log.d(TAG,"Initializing GrowStarry SDK...");

            String appId = maxAdapterInitializationParameters.getServerParameters().get("app_id").toString();
            if (TextUtils.isEmpty(appId)) {
                onCompletionListener.onCompletion(InitializationStatus.INITIALIZED_FAILURE, "init error");
                return;
            }
            Context context = (activity != null) ? activity.getApplicationContext() : getApplicationContext();
            GrowsTarrySDK.initialize(context, maxAdapterInitializationParameters.getServerParameters().get("app_id").toString());
            onCompletionListener.onCompletion(InitializationStatus.INITIALIZED_SUCCESS, "init success");
            return;
        }

        onCompletionListener.onCompletion(InitializationStatus.DOES_NOT_APPLY, null);
    }

    @Override
    public String getSdkVersion() {
        return null;
    }

    @Override
    public String getAdapterVersion() {
        return null;
    }

    @Override
    public void onDestroy() {

    }

    @Override
    public void loadInterstitialAd(MaxAdapterResponseParameters maxAdapterResponseParameters, Activity activity, MaxInterstitialAdapterListener maxInterstitialAdapterListener) {
        String placementId = maxAdapterResponseParameters.getThirdPartyAdPlacementId();
        if (TextUtils.isEmpty(placementId)) {
            maxInterstitialAdapterListener.onInterstitialAdLoadFailed(MaxAdapterError.INVALID_CONFIGURATION);
            return;
        }
        GrowsTarrySDK.preloadInterstitialAd(activity, placementId, new InterstitialListener(maxInterstitialAdapterListener));
    }

    @Override
    public void showInterstitialAd(MaxAdapterResponseParameters maxAdapterResponseParameters, Activity activity, MaxInterstitialAdapterListener maxInterstitialAdapterListener) {
        GrowsTarrySDK.showInterstitialAd(interstitial);
    }

    @Override
    public void loadRewardedAd(MaxAdapterResponseParameters maxAdapterResponseParameters, Activity activity, MaxRewardedAdapterListener listener) {
        String placementId = maxAdapterResponseParameters.getThirdPartyAdPlacementId();
        if (TextUtils.isEmpty(placementId)) {
            listener.onRewardedAdLoadFailed(MaxAdapterError.INVALID_CONFIGURATION);
            return;
        }
        GrowsTarryVideo.preloadRewardedVideo(activity, placementId,
                new VideoAdLoadListener() {
                    @Override
                    public void onVideoAdLoadSucceed(GTVideo videoAd) {
                        Log.d(TAG,"video ad loaded");
                        video = videoAd;
                        listener.onRewardedAdLoaded();
                    }


                    @Override
                    public void onVideoAdLoadFailed(GTError error) {
                        Log.d(TAG,(error.getMsg()));
                        listener.onRewardedAdLoadFailed(null);
                    }

                });
    }

    @Override
    public void showRewardedAd(MaxAdapterResponseParameters maxAdapterResponseParameters, Activity activity, MaxRewardedAdapterListener listener) {
        if(GrowsTarryVideo.isRewardedVideoAvailable(video)){
            GrowsTarryVideo.showRewardedVideo(video, new RewardedVideoAdListener() {

                @Override
                public void videoStart() {
                    listener.onRewardedAdDisplayed();
                    listener.onRewardedAdVideoStarted();
                }

                @Override
                public void videoFinish() {
                }

                @Override
                public void videoError(Exception e) {
                    listener.onRewardedAdDisplayFailed(MaxAdapterError.REWARD_ERROR);

                }

                @Override
                public void videoClosed() {
                    listener.onRewardedAdHidden();

                }


                @Override
                public void videoClicked() {
                    listener.onRewardedAdClicked();
                }


                @Override
                public void videoRewarded(String rewardName, String rewardAmount) {
                    listener.onRewardedAdVideoCompleted();
                    int amount = 0;
                    try {
                        amount = Integer.parseInt(rewardAmount);
                    } catch (NumberFormatException e) {
                        e.printStackTrace();
                    }
                    MaxReward reward=MaxRewardImpl.create(amount,rewardName);
                    listener.onUserRewarded(reward);
                }

            });
        }else{
            listener.onRewardedAdDisplayFailed(MaxAdapterError.REWARD_ERROR);
            Log.d(TAG,"Attempted to show rewarded video before it was available.");

        }
    }


    private class InterstitialListener extends AdEventListener {

        private final MaxInterstitialAdapterListener listener;

        private InterstitialListener(final MaxInterstitialAdapterListener listener) {
            this.listener = listener;
        }

        @Override
        public void onReceiveAdSucceed(GTNative result) {
            Log.d(TAG,"Interstitial ad loaded");
            listener.onInterstitialAdLoaded();
            interstitial = result;
        }

        @Override
        public void onReceiveAdVoSucceed(AdsVO result) {

        }

        @Override
        public void onShowSucceed(GTNative result) {
            super.onShowSucceed(result);
            Log.d(TAG,"Interstitial show");
            listener.onInterstitialAdDisplayed();
        }

        @Override
        public void onLandPageShown(GTNative result) {
            Log.d(TAG,"Interstitial did open");
        }


        @Override
        public void onReceiveAdFailed(GTNative result) {
            Log.d(TAG,"Interstitial failed to load: " + result.getErrorsMsg());
            listener.onInterstitialAdLoadFailed(null);
        }


        @Override
        public void onAdClicked(GTNative result) {
            Log.d(TAG,"Interstitial left the application");

            listener.onInterstitialAdClicked(); // MoPub adapter fires this in onAdLeave()
        }


        @Override
        public void onAdClosed(GTNative result) {
            Log.d(TAG,"Interstitial ad closed");

            listener.onInterstitialAdHidden();
            interstitial = null;
        }

    }
}
